# Jogo do Mario
<img src = "/assets/imgs/print-jogo-do-mario.jpeg" >
Jogo do Mario utilizando HTML, CSS e Javascript cujo o objetivo é o Mario saltar por cima dos tubos
